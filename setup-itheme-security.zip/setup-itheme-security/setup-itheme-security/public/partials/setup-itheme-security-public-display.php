<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://www.wpthemestore.co.uk
 * @since      1.0.0
 *
 * @package    Setup_Itheme_Security
 * @subpackage Setup_Itheme_Security/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
