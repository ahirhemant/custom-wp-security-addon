<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://www.wpthemestore.co.uk
 * @since      1.0.0
 *
 * @package    Setup_Itheme_Security
 * @subpackage Setup_Itheme_Security/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Setup_Itheme_Security
 * @subpackage Setup_Itheme_Security/admin
 * @author     Ahir Hemant <ahirhemant786@gmail.com>
 */
class Setup_Itheme_Security_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Setup_Itheme_Security_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Setup_Itheme_Security_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/setup-itheme-security-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Setup_Itheme_Security_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Setup_Itheme_Security_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/setup-itheme-security-admin.js', array( 'jquery' ), $this->version, false );

	}
	
	/**
     * Register admin page
    */
    public function Sis_load_admin_pages()
    {
		add_menu_page(__('Setup ITheme Security', 'setup-itheme-security') , __('Setup ITheme Security', 'setup-itheme-security') , 'manage_options', 'medtutor-settings', array(
            $this,'Sis_render_settings_page'));

	}
	
	/**
     * Takes care of rendering the settings page
    */
    public function Sis_render_settings_page()
    {
        require_once plugin_dir_path(__FILE__) . 'partials/setup-itheme-security-settings.php';
	}
	
	/**
     * Takes care of admin notice if parent plugin is not active
    */
	public function Sis_itheme_admin_notice(){
		$currentScreen = get_current_screen();		
		if( $currentScreen->id === "toplevel_page_medtutor-settings" ) {
			echo '<div class="notice notice-error is-dismissible">
				<p>Please activate ITheme Security Plugin</p>
				</div>';
		}
	}

}