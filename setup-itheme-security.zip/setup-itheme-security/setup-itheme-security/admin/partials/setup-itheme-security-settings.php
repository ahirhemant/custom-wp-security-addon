<?php
/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://www.wpthemestore.co.uk
 * @since      1.0.0
 *
 * @package    Setup_Itheme_Security
 * @subpackage Setup_Itheme_Security/admin/partials
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$nonce_code = 'setup-settings';
$nonce = wp_create_nonce( $nonce_code );

if($_SERVER['REQUEST_METHOD'] == 'POST' && wp_verify_nonce($_POST['nonce'], $nonce_code)){
    foreach($_POST as $key => $value){
        if( is_plugin_active( 'better-wp-security/better-wp-security.php' ) ) {
            if($key == 'exclude_file_list'){
                $new_exclude_list['file_list'] = explode("\n", str_replace("\r", "", $value));
                
                $no_exists_value = get_option( 'itsec-storage' );  
                foreach($no_exists_value as $key => $file_change_arr){		
                    if($key == "file-change"){
                        $new_file_change_arr = array_replace($file_change_arr,$new_exclude_list);                    
                    }
                }
                $no_exists_value['file-change'] = $new_file_change_arr;	
                update_option('itsec-storage', $no_exists_value);	
            }
            if($key == 'ignore_file_types'){
                
                $new_ignore_file_types['types'] = explode("\n", str_replace("\r", "", $value));
                $no_exists_value = get_option( 'itsec-storage' );  
                foreach($no_exists_value as $key => $file_change_arr){		
                    if($key == "file-change"){                        
                        $new_new_ignore_file_types_arr = array_replace($file_change_arr,$new_ignore_file_types);                       
                    }
                }
                
                $no_exists_value['file-change'] = $new_new_ignore_file_types_arr;	
                update_option('itsec-storage', $no_exists_value);	
            }
        }
    }
}

if( is_plugin_active( 'better-wp-security/better-wp-security.php' ) ) {
    $exclude_files_array = !empty(get_option('itsec-storage')) ? get_option('itsec-storage') : '';
    $exclude_files ="";
    $ignore_file_types ="";
    foreach($exclude_files_array as $key => $file_change_arr){		
        if($key == "file-change"){
            $exclude_files = implode("\n", str_replace("\r", "", $file_change_arr['file_list']));
            $ignore_file_types = implode("\n", str_replace("\r", "", $file_change_arr['types']));
        }
    }    
}
?>
<h3><?php _e('Settings','setup-itheme-security'); ?></h3>
<form action="#" method="POST">
    <table class="widefat" style="border: 0px;">
        <tr>
            <td colspan="2"><h3><?php echo __('General options','setup-itheme-security'); ?></h3></td>
        </tr>
    
        <?php 
            if( is_plugin_active( 'better-wp-security/better-wp-security.php' ) ) {
        ?>
        <tr>
            <td colspan="2"><h3><?php echo __('Exclude file list','setup-itheme-security'); ?></h3></td>
        </tr>
        <tr>
            <td colspan="2">
                <textarea id="fancy-textarea" cols="50" rows="10" wrap="off" name="exclude_file_list"><?php echo stripslashes($exclude_files); ?></textarea>
				<p class="description"><?php echo __('Enter directory path per row one e.g wp-content/updraft/ etc','setup-itheme-security'); ?></p>
            </td>
        </tr>
        <tr>
            <td colspan="2"><h3><?php echo __('Ignore File Types','setup-itheme-security'); ?></h3></td>
        </tr>
        <tr>
            <td colspan="2">
                <textarea wrap="off" cols="50" rows="10" type="textarea" name="ignore_file_types" id="ignore_file_types" spellcheck="false"><?php echo stripslashes($ignore_file_types); ?></textarea>
				<p class="description"><?php echo __('Enter file types per row one e.g .txt,.png,.pdf etc','setup-itheme-security'); ?></p>
            </td>
        </tr>
        <?php } ?>
        <tr>
            <td colspan="2">
                <input type="hidden" name="nonce" value="<?php echo $nonce; ?>"/>
                <input type="submit" class="button button-primary btn" value="<?php _e('Save','setup-itheme-security'); ?>"/>
            </td>
        </tr>    
        
    </table>
</form>