<?php

/**
 * Fired during plugin activation
 *
 * @link       https://www.wpthemestore.co.uk
 * @since      1.0.0
 *
 * @package    Setup_Itheme_Security
 * @subpackage Setup_Itheme_Security/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Setup_Itheme_Security
 * @subpackage Setup_Itheme_Security/includes
 * @author     Ahir Hemant <ahirhemant786@gmail.com>
 */
class Setup_Itheme_Security_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

        $default_exclude = array("file-change"=>array("file_list"=>array("0"=>"wp-content/updraft/","1"=>"404.php"),"types"=>array("0"=>".txt","1"=>".pdf")));
        
        $no_exists_value = get_option( 'itsec-storage' );
        if($no_exists_value){
            if (!array_key_exists("file-change",$no_exists_value)){
                $new_file_change_arr = array_merge($no_exists_value,$default_exclude);
                update_option('itsec-storage', $new_file_change_arr);
            }           
        }
	}

}