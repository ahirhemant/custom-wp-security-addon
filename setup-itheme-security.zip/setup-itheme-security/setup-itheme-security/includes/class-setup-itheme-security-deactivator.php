<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://www.wpthemestore.co.uk
 * @since      1.0.0
 *
 * @package    Setup_Itheme_Security
 * @subpackage Setup_Itheme_Security/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Setup_Itheme_Security
 * @subpackage Setup_Itheme_Security/includes
 * @author     Ahir Hemant <ahirhemant786@gmail.com>
 */
class Setup_Itheme_Security_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
